package com.kyzer.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.kyzer.user.controller.entity.Contact;
import com.kyzer.user.controller.entity.User;
import com.kyzer.user.controller.service.userService;


@RestController
@RequestMapping("/cont")
public class UserController {

	
	
	@Autowired
	private RestTemplate restTemplate;
 	
	/*
	//For returning the user bean
	@Autowired
	private userService userservice;
	@GetMapping("/{id}")
	
	public User getUser(@PathVariable("id") int id) {
		
		
		System.out.println(id);
		return this.userservice.getUser(id);
		
		}
		
		*/
		
	
	@Autowired
	private userService userservice;
	@GetMapping("/{id}")
	 
	
	//contact is interacting with the user service
	public User getUser(@PathVariable("id") int id){
		User use=this.userservice.getUser(id);
		
		
		//to call the contact api from user api using whole url
//	List contacts= this.restTemplate.getForObject("http://localhost:9005/contact/user/"+id, List.class);
//	use.setContacts(contacts);
		
		
		//to call api directly using the contact service instance from eureka
		List contacts= this.restTemplate.getForObject("http://contact-service/contact/user/"+id, List.class);	
	use.setContacts(contacts);
	return use;
	

	
 }
}
