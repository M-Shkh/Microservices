package com.kyzer.user.controller.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
//import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.kyzer.user.controller.entity.User;

@ComponentScan
@Service

public class UserServiceImpl implements userService {

//	
//	List<User>info = List.of(
//			
//			new User(1001,"Maseera Shaikh","9876547"),
//			 new User(1002,"Aram khan","123456"),
//			 new User(1003,"Another","657487") 
//			
//			);
//	
//	
	
	List<User> info=new ArrayList<User>();
	
	
	UserServiceImpl(){
		User user1 = new User(1001,"Maseera Shaikh","9876547");
		User user2 = new User(1002,"Aram khan","123456");
		User user3 = new User(1003,"Another","657487");
		info.add(user1);
	    info.add(user2);
		info.add(user3);
	}

	@Override
	public User getUser(int id) {
		
	//this method will return the filter sequence of if from user or else will return null
		
		return this.info.stream().filter(user->user.getUserId()==(id)).findAny().orElse(null);
		
		
		//A stream() is a sequence of objects that supports various methods which can be pipelined to produce the desired result.
		//The filter() function of the Java stream allows you to narrow down the stream's items based on a criterion
	}

	
//	
//public List<User> addUserIntoList(){
////
//	User user1 = new User(1001,"Maseera Shaikh","9876547");
//	User user2 = new User(1002,"Aram khan","123456");
//	User user3 = new User(1003,"Another","657487");
//	info.add(user1);
//    info.add(user2);
//	info.add(user3);
////	
////	System.out.println(info);
//    return info;
//}
//	

}

	
	
	
