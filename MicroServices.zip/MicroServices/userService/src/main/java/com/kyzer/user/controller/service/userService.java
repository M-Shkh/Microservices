package com.kyzer.user.controller.service;

import com.kyzer.user.controller.entity.User;

public interface userService {

	public User getUser(int id);
}
