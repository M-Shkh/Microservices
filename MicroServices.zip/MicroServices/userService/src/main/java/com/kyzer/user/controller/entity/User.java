package com.kyzer.user.controller.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;


@Component
public class User {

	private int userId;
	private String Name;
	private String Phone;
	
	List<Contact> contacts = new ArrayList<>();

	public User(int userId, String name, String phone, List<Contact> contacts) {
		super();
		this.userId = userId;
		Name = name;
		Phone = phone;
		this.contacts = contacts;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getPhone() {
		return Phone;
	}

	public void setPhone(String phone) {
		Phone = phone;
	}

	public List<Contact> getContacts() {
		return contacts;
	}

	public void setContacts(List<Contact> contacts) {
		this.contacts = contacts;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", Name=" + Name + ", Phone=" + Phone + ", contacts=" + contacts + "]";
	}

	public User(int userId, String name, String phone) {
		super();
		this.userId = userId;
		Name = name;
		Phone = phone;
	}

	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

}
