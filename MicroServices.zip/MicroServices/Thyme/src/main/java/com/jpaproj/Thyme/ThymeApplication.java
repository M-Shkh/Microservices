   package com.jpaproj.Thyme;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;


import com.jpaproj.Thyme.Repository.userRepo;
import com.jpaproj.Thyme.entities.user;

@SpringBootApplication
public class ThymeApplication {

	@Autowired
	userRepo userrepo;
	
	public static void main(String[] args) {
		ApplicationContext con =SpringApplication.run(ThymeApplication.class, args);
		
		userRepo repo=con.getBean(userRepo.class);

		user user1= new user();
		user1.setId(1);
		user1.setName("Maseera");
		ThymeApplication tx=new ThymeApplication();
		tx.dummy(user1);
		//user save = userrepo.save(user1);
		
		
	//	System.out.println("Saved user is" +save);
	}
    public void dummy(user user1){
    	user save = userrepo.save(user1);
    }
}
 