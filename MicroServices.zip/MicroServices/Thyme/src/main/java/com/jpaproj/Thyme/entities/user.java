package com.jpaproj.Thyme.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity    //fields to map in db
public class user {
  
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int id;
	
	private String name;
	
	
	@Override
	public String toString() {
		return "user [id=" + id + ", name=" + name + "]";
	}

//	public user(int id, String name) {
//		super();
//		this.id = id;
//		this.name = name;
//	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	
	
}
 