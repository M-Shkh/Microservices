package com.jpaproj.Thyme.Repository;


import org.springframework.data.repository.CrudRepository;

import com.jpaproj.Thyme.entities.user;

public interface userRepo extends CrudRepository<user, Integer> {

}
