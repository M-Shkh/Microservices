package com.kyzer.contact.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.kyzer.contact.entity.Contact;

@Service
public class ContactServiceImpl implements ContactService {

	List<Contact> list= new ArrayList<Contact>();
	
	ContactServiceImpl(){
		Contact con1 = new Contact(1L,"maseera@gmail.com","Maseera",1001);
		Contact con2 = new Contact(2L,"aram@gmail.com","Aram",1002);
		Contact con3 = new Contact(3L,"another@gmail.com","Another",1003);
		list.add(con1);
		list.add(con2);
		list.add(con3);
		
	}
	
	
	@Override
	public List<Contact> getUserContact(int userId) {
		
		
		
		return this.list.stream().filter(contact->contact.getUserId()==userId).collect(Collectors.toList());
	}

	
}
