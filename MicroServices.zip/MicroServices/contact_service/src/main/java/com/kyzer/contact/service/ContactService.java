package com.kyzer.contact.service;
import java.util.List;

import com.kyzer.contact.entity.*;

public interface ContactService {

	public List<Contact> getUserContact(int userId);
}
