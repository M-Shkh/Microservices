package com.info.ToDo.Reposit;

import org.springframework.data.jpa.repository.JpaRepository;

import com.info.ToDo.info.UsersInfo;

public interface TodoRepo extends JpaRepository<UsersInfo, Long> {

}
