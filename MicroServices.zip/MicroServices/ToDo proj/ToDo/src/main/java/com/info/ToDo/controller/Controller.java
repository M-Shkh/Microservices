package com.info.ToDo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.info.ToDo.Reposit.TodoRepo;
import com.info.ToDo.info.UsersInfo;

@RestController
@RequestMapping("/todo")
public class Controller {

	@Autowired
	private TodoRepo repo;
	
	
	@GetMapping
	public List<UsersInfo> findAll(){
		return repo.findAll();
	}
	
	@PostMapping
	public UsersInfo save(@RequestBody UsersInfo user){
		return repo.save(user);
	}
	
	
	
	@GetMapping("/hello")
	public String hello(){
		return "Hello user , welcome to the ToDo list";
	}
}
