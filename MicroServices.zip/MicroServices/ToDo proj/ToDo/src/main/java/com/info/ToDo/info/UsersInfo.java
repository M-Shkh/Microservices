package com.info.ToDo.info;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.sun.istack.NotNull;

@Entity
public class UsersInfo {
  private long Id;
  @NotNull
  private String Title;
  private boolean Done;
  
  @Id
  @GeneratedValue
public long getId() {
	return Id;
}
public void setId(long id) {
	Id = id;
}
public String getTitle() {
	return Title;
}
public void setTitle(String title) {
	Title = title;
}
public boolean isDone() {
	return Done;
}
public void setDone(boolean done) {
	Done = done;
}
public UsersInfo(long id, String title, boolean done) {
	super();
	Id = id;
	Title = title;
	Done = done;
}
@Override
public String toString() {
	return "UsersInfo [Id=" + Id + ", Title=" + Title + ", Done=" + Done + "]";
}
  
  
	
	
}
