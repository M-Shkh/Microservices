package com.info.task.Routine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoutineApplicationTests {

	@Test
	void contextLoads() {
	}

}
